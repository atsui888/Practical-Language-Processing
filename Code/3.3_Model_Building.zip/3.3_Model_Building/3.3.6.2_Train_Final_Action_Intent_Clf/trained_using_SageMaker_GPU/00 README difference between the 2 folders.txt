Both distilBERT and tinyBERT folder are the same model building code and results.

The difference is in the last part where I selected which model to create a HF repo and upload to the hub.