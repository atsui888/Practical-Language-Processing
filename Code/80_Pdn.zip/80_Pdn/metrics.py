from datetime import datetime as dt
import duckdb as ddb
from pathlib import Path
import sys
common_code_path = Path.cwd().parent / "plp_common_code"
print(common_code_path)
if str(common_code_path) not in sys.path:
    sys.path.append(str(common_code_path))
try:
    from amhere import foundme
    foundme()
    del foundme
except Exception as e:
    print(e)
finally:
    del common_code_path

class Metrics:
    def __init__(self):
        self._cwd = Path.cwd()
        self._db_path = self._cwd / 'database'
        self._db_file_name = 'aspect_topic_db.parquet'  # db path
        self._db_path_file = self._db_path / self._db_file_name
        self._db_aspect_topic = ddb.read_parquet(str(self._db_path_file)).to_df()
        self._db_at_subset = None  # at i.e. aspect topic

        self._output_path = self._cwd / 'data_output'
        self._output_csv_path_file = None
        self._output_parquet_path_file = None

        self._dlg_start_date = None

    def subset_aspect_topic_by_date_range(self, start_dtd: str='', end_dtd: str=''):
        """
        if start_dtd not given, it will be today
        if end_dtd not given, it will be today
        if end_dtd < start_dtd, it will be the same as start_dtd
        :param start_dtd:
        :param end_dtd:
        :return:
        """

        # todo: NOTES:
        # todo: In the dashboard, end_dtd is not implemented yet

        now = dt.now()
        now_date_str = str(now.year).zfill(4) + '-' + str(now.month).zfill(2) + '-' + str(now.day).zfill(2)
        if len(start_dtd) < 10:  # empty not declared or incomplete 'YYYY-MM-DD'
            start_dtd = now_date_str
        if len(end_dtd) < 10:
            end_dtd = now_date_str
        if end_dtd < start_dtd:
            end_dtd = start_dtd

        self._dlg_start_date = start_dtd  # in dashboard, end_dtd is not implemented yet

        dft = self._db_aspect_topic  # this is coz duckdb can't seem to pick up python class vars
        # so workaround is to assign it to a local var
        sql_query = f"""
        select * from dft where date >= '{start_dtd}' and date <= '{end_dtd}';
        """
        # print('\n\n', sql_query)
        self._db_at_subset = ddb.query(sql_query).to_df()
        del dft


if __name__ == "__main__":
    pass
