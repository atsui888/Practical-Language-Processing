"""
IngestDialog.py

1.0 Load new simulated multi-turn dialog
2.0 Data Pre-processing (extract customer utterance only and drop unnecessary columns)
    2.1 Identify Product from Customer Utterance
    2.2 Identify Action from Customer Utterance
    2.3 Classify Sentiment from Customer Utterance
    2.4 Create Aspect Topic column
3.0 Append to Topics Database (using parquet to simulate for purpose of POC)
- if there is existing data in Topics Database, we append to it.

"""

import pandas as pd
from pathlib import Path
import sys

common_code_path = Path.cwd().parent / "plp_common_code"

if str(common_code_path) not in sys.path:
    sys.path.append(str(common_code_path))
from amhere import foundme
foundme()  # this fn will fail if common code path is not found or !exists
del foundme
del common_code_path

from clf_Helper import load_hf_pdt_clf



class IngestDialog:
    def __init__(self, dlg_file_name: str, file_type: str='csv'):
        # self._dlg_file_name = dlg_file_name  # Currently accepts CSV file only
        cwd = Path.cwd()
        self._data_input_path = cwd / 'data_input'
        self._dlg_path_file = self._data_input_path / dlg_file_name

        match file_type:
            case 'csv':
                self._df = pd.read_csv(self._dlg_path_file)
            case 'parquet':
                self._df = pd.read_parquet(self._dlg_path_file)
            case _:
                raise SystemError('IngestDialog() --> __init__ -> file type not supported.')

        self._prep_data()
        self._pdt_clf, self._action_clf, self._sentiment_clf = self._load_classifiers()

        print("Identifying Products from Dialog Text...")
        self._identify_product()
        print("Identifying Actions from Dialog Text...")
        self._identify_action()
        print("Classifying Sentiment from Dialog Text...")
        self._classify_sentiment()
        print("Creating Aspect Topics")
        self._create_aspect_topic()
        print("Appending new customer utterances to aspect_topic_db")
        self._append_to_aspect_topic_db()

        print(self._df.head(3))
        print('ingestion of new multi-turn dialog data to customer utterances complete.')


    def _prep_data(self):
        """
        # keep required columns only
        :return:
        """
        required_cols = ['date', 'dlg_id', 'text']
        self._df = self._df[required_cols]

        # replace blanks by NaN
        self._df = self._df.replace(r'^s*$', float('NaN'), regex = True)
        self._df.dropna(inplace=True)


    @staticmethod
    def _load_classifiers():
        pdt_clf = load_hf_pdt_clf(
            nlp_task='text-classification',
            hf_model_chkpt="richardchai/plp_pdt_clr_tinybert")

        action_clf = load_hf_pdt_clf(
            nlp_task='text-classification',
            hf_model_chkpt="richardchai/plp_action_clr_distilbert")

        sentiment_clf = load_hf_pdt_clf(
            nlp_task='text-classification',
            hf_model_chkpt="richardchai/plp_sentiment_clr_distilbert")
        return pdt_clf, action_clf, sentiment_clf

    def _identify_product(self):
        def predict_product(x: [str, list]):
            response = self._pdt_clf(x)
            product = [r['label'] for r in response]
            if isinstance(product, list) and len(product) < 2:
                return product[0]
            else:
                return str(product)[1:-1]

        # temp_df = self._df.iloc[0:3, :]
        # print(type(temp_df))
        # print(temp_df)
        # print(temp_df['text'].apply(lambda x: predict_product(x)))

        # need to drop empty 'text' rows? in data prep?

        self._df['product'] = self._df['text'].apply(lambda x: predict_product(x))

    def _identify_action(self):
        def predict_action(x: [str, list]):
            response = self._action_clf(x)
            action = [r['label'] for r in response]

            if isinstance(action, list) and len(action) < 2:
                return action[0]
            else:
                return str(action)[1:-1]
        self._df['action'] = self._df['text'].apply(lambda x: predict_action(x))

    def _classify_sentiment(self):
        def predict_sentiment(x: [str, list]):
            response = self._sentiment_clf(x)
            sentiment = [r['label'] for r in response]

            if isinstance(sentiment, list) and len(sentiment) < 2:
                return sentiment[0]
            else:
                return str(sentiment)[1:-1]
        self._df['sentiment'] = self._df['text'].apply(lambda x: predict_sentiment(x))

    def _create_aspect_topic(self):
        self._df['aspect_topic'] = self._df['action'] + '__' + self._df['product']

    def _append_to_aspect_topic_db(self):
        temp_df = pd.read_parquet("database/aspect_topic_db.parquet")
        print(f"Existing topics_db.shape: {temp_df.shape}")
        print(f"self_df.shape: {self._df.shape}")
        topics_db = pd.concat([temp_df, self._df])
        topics_db.reset_index(drop=True, inplace=True)
        print(f"New topics_db.shape: {topics_db.shape}")
        topics_db.to_parquet('database/aspect_topic_db.parquet', index=False)
        topics_db.to_csv('database/aspect_topic_db.csv', index=False, encoding='utf-8-sig')


if __name__ == "__main__":
    # ingest_dialog = IngestDialog("Synth_400_banking_multi-turn_dlg.parquet", file_type='parquet')
    ingest_dialog = IngestDialog("Synth_400_banking_multi-turn_dlg.csv", file_type='csv')














