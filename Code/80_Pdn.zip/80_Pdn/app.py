import streamlit as st
import pandas as pd
from datetime import timedelta
from datetime import datetime as dt
from pathlib import Path
# from streamlit import header
import streamlit.components.v1 as components

# Set page config
st.set_page_config(page_title="Aspect Based Sentiment Analysis - Net Promoter Score", layout="wide")  #

# global
df_absa_groups = None
df_absa_results = None
df_topic_modeling = None

cwd = Path.cwd()
data_output_path = cwd / 'data_output'

# Helper functions
@st.cache_data
def load_data(load_type: str, load_date: str):
    match load_type:
        case 'absa_nps':
            groups_filename = 'absa_nps_groups_' + load_date + '.parquet'
            groups_path_file = data_output_path / groups_filename
            score_filename = 'absa_nps_score_' + load_date + '.parquet'
            score_path_file = data_output_path / score_filename
            data_1 = pd.read_parquet(groups_path_file)
            data_2 = pd.read_parquet(score_path_file)
            return data_1, data_2
        case 'absa_csat':
            groups_filename = 'absa_csat_groups_' + load_date + '.parquet'
            groups_path_file = data_output_path / groups_filename
            score_filename = 'absa_csat_score_' + load_date + '.parquet'
            score_path_file = data_output_path / score_filename
            data_1 = pd.read_parquet(groups_path_file)
            data_2 = pd.read_parquet(score_path_file)
            return data_1, data_2
        case 'tm_nmf':
            results_filename = 'topic_modeling_nmf_results_' + load_date + '.parquet'
            results_path_file = data_output_path / results_filename
            data_1 = pd.read_parquet(results_path_file)
            return data_1
        case 'tm_bertopic':
            results_filename = 'topic_modeling_bertopic_results_' + load_date + '.parquet'
            results_path_file = data_output_path / results_filename
            data_1 = pd.read_parquet(results_path_file)
            return data_1
        case _:
            raise  SystemError("Unknown 'load_type'")


def display_metric(metric_col, analysis_type, metric_title, metric_value, metric_delta, chart_color):
    with metric_col:
        match analysis_type:
            case 'ABSA-NPS':
                with st.container(border=True):
                    if metric_title == 'Score':
                        st.metric(metric_title, metric_value, delta=metric_delta)
                        # st.bar_chart(chart_data, y=column, color=color, height=150)
                        st.caption(f"Ranges from -100 to 100 (worst -- best)")
                    elif metric_title == 'Distribution':
                        total_respondents = df_absa_results.loc[0, 'total_respondents']
                        num_promoters = df_absa_results.loc[0, 'num_promoters']
                        num_detractors = df_absa_results.loc[0,'num_detractors']
                        num_passives = total_respondents - num_promoters - num_detractors

                        chart_data = {
                            'nps_groups': ["Detractors", "Passives", "Promoters", "Total"],
                            'num_dialogs': [num_detractors, num_passives, num_promoters, total_respondents]
                        }
                        st.bar_chart(chart_data, x='nps_groups', y='num_dialogs',
                                     y_label='No of Dialogs', x_label='NPS Groups',
                                     horizontal=True, use_container_width=False, color=chart_color)
                    else:
                        return
            case 'ABSA-CSAT':
                with st.container(border=True):
                    if metric_title == 'Score':
                        st.metric(metric_title, metric_value, delta=metric_delta)
                        # st.bar_chart(chart_data, y=column, color=color, height=150)
                        st.caption(f"Pct of customers who are 'satisfied' and 'very satisfied' (0 -- 100).")
                    elif metric_title == 'Distribution':
                        total_respondents = df_absa_results.loc[0, 'total_responses']
                        num_satisfied = df_absa_results.loc[0, 'num_satisfied']
                        num_dissatisfied = total_respondents - num_satisfied

                        chart_data = {
                            'csat_groups': ["Total", "Satisfied", "Disatisfied"],
                            'num_respondents': [total_respondents, num_satisfied, num_dissatisfied]
                        }
                        st.bar_chart(chart_data, x='csat_groups', y='num_respondents',
                                     y_label='Sentiment', x_label='Count',
                                     horizontal=True, use_container_width=False, color=chart_color)
                    else:
                        return
            case 'Topic Modeling - NMF':
                # no metrics to display for NMF
                return
            case 'Topic Modeling - BERTopic':
                # no metrics to display for NMF
                return
            case _:
                return

# Set up input widgets
# st.logo(image="images/streamlit-logo-primary-colormark-lighttext.png",
#         icon_image="images/streamlit-mark-color.png")

with st.sidebar:
    st.title("Topics and Sentiment mined from Customer Dialog")
    st.header("⚙️ Settings")

    # default_date = dt.strptime("2024-10-01", "%Y-%m-%d").date()
    # max_date = dt.strptime("2024-10-31", "%Y-%m-%d").date()
    # selected_date = st.date_input("Date", default_date, min_value=default_date, max_value=max_date)

    selected_date = st.selectbox("Date", ("2024-10-05", "2024-10-23"))
    analysis_type = st.selectbox("Type of Topic Analysis", ("ABSA-NPS", "ABSA-CSAT", "Topic Modeling - NMF",
                                                         "Topic Modeling - BERTopic"))


header_text = None
match analysis_type:
    case 'ABSA-NPS':
        header_text = 'Aspect Based Sentiment Mining: Net Promoter Score (NPS)'
        df_absa_groups, df_absa_results = load_data(load_type='absa_nps', load_date=selected_date)
        # remove if avg_sentiment_score is 0, system was not able to detect and put in a 0 as placeholder
        # for future iteration to determine what issues resulted in non-detection
        # df.drop(df[df.score < 50].index, inplace=True)
        df_absa_groups.drop(df_absa_groups[df_absa_groups['avg_sentiment_score']==0].index, inplace=True)
    case 'ABSA-CSAT':
        header_text = 'Aspect Based Sentiment Mining: Customer Satisfaction Score (CSAT)'
        df_absa_groups, df_absa_results = load_data(load_type='absa_csat', load_date=selected_date)
        df_absa_groups.drop(df_absa_groups[df_absa_groups['avg_csat_lbl_score'] == 0].index, inplace=True)
    case 'Topic Modeling - NMF':
        header_text = 'Topic Modeling: Non-Negative Matrix Factorisation'
        df_topic_modeling = load_data(load_type='tm_nmf', load_date=selected_date)
        df_topic_modeling.drop(df_topic_modeling[df_topic_modeling['sentiment_score'] == 0].index, inplace=True)
        # llm can create duplicate "probable topics", we need to either rename it or drop it.
        df_topic_modeling.reset_index(drop=True, inplace=True)
        existing_values = set()
        for row in df_topic_modeling.itertuples():
            if row.probable_topic in existing_values:
                df_topic_modeling.loc[row.Index, 'probable_topic'] = (
                        df_topic_modeling.loc[row.Index, 'probable_topic'] +'_'+ str(row.Index))
            else:
                existing_values.add(row.probable_topic)


    case 'Topic Modeling - BERTopic':
        header_text = 'Topic Modeling: BERTopic'
        df_topic_modeling = load_data(load_type='tm_bertopic', load_date=selected_date)
        df_topic_modeling.drop(df_topic_modeling[df_topic_modeling['sentiment_score'] == 0].index, inplace=True)
        df_topic_modeling.reset_index(drop=True, inplace=True)
        existing_values = set()
        for row in df_topic_modeling.itertuples():
            if row.probable_topic in existing_values:
                df_topic_modeling.loc[row.Index, 'probable_topic'] = (
                        df_topic_modeling.loc[row.Index, 'probable_topic'] + '_' + str(row.Index))
            else:
                existing_values.add(row.probable_topic)
    case _:
        header_text = 'error, check match structure'

# ******************* Display Key Metrics *********************************************************
st.subheader(header_text)
metrics = [('Score', 'col_name_1_unused', '#29b5e8'),
           ('Distribution', 'col_name_2_unused', '#FF9F36')]

cols = st.columns(2)
for col, (METRIC_TITLE, df_col_name, color) in zip(cols, metrics):
    match analysis_type:
        case 'ABSA-NPS':
            if METRIC_TITLE == 'Score':
                METRIC_VALUE = int(df_absa_results.loc[0, 'nps'])
                METRIC_DELTA = 'na'
            elif METRIC_TITLE == 'Distribution':
                METRIC_VALUE = 0
                METRIC_DELTA = 'na'
            else:
                METRIC_VALUE = 0
                METRIC_DELTA = 'na'
            display_metric(col, analysis_type, METRIC_TITLE, METRIC_VALUE, METRIC_DELTA, color)
        case 'ABSA-CSAT':
            METRIC_VALUE = int(df_absa_results.loc[0, 'csat_score'])
            METRIC_DELTA = 'na'
            display_metric(col, analysis_type, METRIC_TITLE, METRIC_VALUE, METRIC_DELTA, color)
        case 'Topic Modeling - NMF':
            pass
        case 'Topic Modeling - BERTopic':
            pass
        case _:
            raise SystemError("Error: no analysis type!")



# ******************* Display Charts *************************************************************
st.subheader('Charts')
top_topics = 10

match analysis_type:
    case 'ABSA-NPS':
        df_absa_groups['avg_sentiment_score'] = (
            df_absa_groups['avg_sentiment_score'].apply(lambda x: round(x, 1)))
        # sort
        st.html("<b>Top 10 Positive - NPS</b>")
        df_sorted_pos = df_absa_groups.sort_values(by='avg_sentiment_score', ascending=False).copy()
        df_sorted_pos = df_sorted_pos.iloc[:top_topics, :].sort_values(by='aspect_topic', ascending=True)
        df_sorted_neg = df_absa_groups.sort_values(by='avg_sentiment_score', ascending=True).copy()
        df_sorted_neg = df_sorted_neg.iloc[:top_topics, :].sort_values(by='aspect_topic', ascending=True)
        # https://www.colorhexa.com/00ff00
        st.bar_chart(
            data=df_sorted_pos,
            horizontal=True,
            y='avg_sentiment_score', x_label='Avg Sentiment Score',
            x='aspect_topic', y_label='Aspect Topic', color='#00A300')
        st.dataframe(
            df_sorted_pos.loc[:, ['aspect_topic', 'nps_group', 'avg_sentiment_score', 'rep_text']]
            , hide_index=True
            # , use_container_width=True
        )
        st.html("<b>Top 10 Negative - NPS</b>")
        st.bar_chart(
            data=df_sorted_neg,
            horizontal=True,
            y='avg_sentiment_score', x_label='Avg Sentiment Score',
            x='aspect_topic', y_label='Aspect Topic', color='#AA0050')
        st.dataframe(
            df_sorted_neg.loc[:, ['aspect_topic', 'nps_group', 'avg_sentiment_score', 'rep_text']]
            , hide_index=True
            # , use_container_width=True
        )
        # st.caption('Aspect Based Sentiment Analysis - NPS')
    case 'ABSA-CSAT':
        df_absa_groups['avg_csat_lbl_score'] = (
            df_absa_groups['avg_csat_lbl_score'].apply(lambda x: round(x, 1)))
        # sort
        st.html("<b>Top 10 Positive - CSAT</b>")
        df_sorted_pos = df_absa_groups.sort_values(by='avg_csat_lbl_score', ascending=False).copy()
        df_sorted_pos = df_sorted_pos.iloc[:top_topics, :].sort_values(by='aspect_topic', ascending=True)
        df_sorted_neg = df_absa_groups.sort_values(by='avg_csat_lbl_score', ascending=True).copy()
        df_sorted_neg = df_sorted_neg.iloc[:top_topics, :].sort_values(by='aspect_topic', ascending=True)
        # https://www.colorhexa.com/00ff00
        st.bar_chart(
            data=df_sorted_pos,
            horizontal=True,
            y='avg_csat_lbl_score', x_label='Avg CSAT Score',
            x='aspect_topic', y_label='Aspect Topic', color='#00A300')
        st.dataframe(
            df_sorted_pos.loc[:, ['aspect_topic', 'csat_group', 'avg_csat_lbl_score', 'rep_text']]
            , hide_index=True
            # , use_container_width=True
        )
        st.html("<b>Top 10 Negative - CSAT</b>")
        st.bar_chart(
            data=df_sorted_neg,
            horizontal=True,
            y='avg_csat_lbl_score', x_label='Avg CSAT Score',
            x='aspect_topic', y_label='Aspect Topic', color='#AA0050')
        st.dataframe(
            df_sorted_neg.loc[:, ['aspect_topic', 'csat_group', 'avg_csat_lbl_score', 'rep_text']]
            , hide_index=True
            # , use_container_width=True
        )
        # st.caption('Aspect Based Sentiment Analysis - CSAT')
    case 'Topic Modeling - NMF':
        # cols_to_use = ['probable_topic', 'num_of_docs_per_topic', 'sentiment', 'sentiment_score', 'trigger',
        #                'explanation', 'features', 'term_importance']
        # df_topic_modeling

        # sort
        st.html("<b>Top 10 Positive - NMF</b>")
        df_sorted_pos = df_topic_modeling.sort_values(by=['sentiment_score', 'num_of_docs_per_topic', 'probable_topic'],
                                                      ascending=False).copy()
        df_sorted_pos = df_sorted_pos.iloc[:top_topics, :].sort_values(by='probable_topic', ascending=True)

        df_sorted_neg = df_topic_modeling.sort_values(by=['sentiment_score', 'num_of_docs_per_topic', 'probable_topic'],
                                                      ascending=True).copy()
        df_sorted_neg = df_sorted_neg.iloc[:top_topics, :].sort_values(by='probable_topic', ascending=True)

        # https://www.colorhexa.com/00ff00
        st.bar_chart(
            data=df_sorted_pos,
            horizontal=True,
            y='sentiment_score', x_label='Sentiment Score',
            x='probable_topic', y_label='Topic', color='#00A300')
        st.caption("Sentiment Scores: from negative (left) to positive (right)")
        st.dataframe(
            df_sorted_pos.loc[:, ['probable_topic', 'sentiment', 'sentiment_score',
                                  'num_of_docs_per_topic','trigger']]
            , hide_index=True
            # , use_container_width=True
        )

        st.html("<b>Top 10 Negative - NMF</b>")
        st.bar_chart(
            data=df_sorted_neg,
            horizontal=True,
            y='sentiment_score', x_label='Sentiment Score',
            x='probable_topic', y_label='Topic', color='#AA0050')
        st.dataframe(
            df_sorted_neg.loc[:, ['probable_topic', 'sentiment', 'sentiment_score',
                                  'num_of_docs_per_topic','trigger']]
            , hide_index=True
            # , use_container_width=True
        )

    case 'Topic Modeling - BERTopic':
        # sort
        st.html("<b>Top 10 Positive - BERTopic</b>")
        df_sorted_pos = df_topic_modeling.sort_values(by=['sentiment_score', 'Count', 'probable_topic'],
                                                      ascending=False).copy()
        df_sorted_pos = df_sorted_pos.iloc[:top_topics, :].sort_values(by='probable_topic', ascending=True)

        df_sorted_neg = df_topic_modeling.sort_values(by=['sentiment_score', 'Count', 'probable_topic'],
                                                      ascending=True).copy()
        df_sorted_neg = df_sorted_neg.iloc[:top_topics, :].sort_values(by='probable_topic', ascending=True)

        # https://www.colorhexa.com/00ff00
        st.bar_chart(
            data=df_sorted_pos,
            horizontal=True,
            y='sentiment_score', x_label='Sentiment Score',
            x='probable_topic', y_label='Topic', color='#00A300')
        st.caption("Sentiment Scores: from negative (left) to positive (right)")
        st.dataframe(
            df_sorted_pos.loc[:, ['probable_topic', 'sentiment', 'sentiment_score',
                                  'Count', 'Representative_Docs']]
            , hide_index=True
            # , use_container_width=True
        )

        st.html("<b>Top 10 Negative - BERTopic</b>")
        st.bar_chart(
            data=df_sorted_neg,
            horizontal=True,
            y='sentiment_score', x_label='Sentiment Score',
            x='probable_topic', y_label='Topic', color='#AA0050')
        st.dataframe(
            df_sorted_neg.loc[:, ['probable_topic', 'sentiment', 'sentiment_score',
                                  'Count', 'Representative_Docs']]
            , hide_index=True
            # , use_container_width=True
        )
    case _:
        header_text = 'error, check match structure, unsure what analysis dataframe to display.'

# ******************* Insights *****************************************************************
st.subheader('Insights & Recommendations')
match analysis_type:
    case 'ABSA-NPS':
        st.write("insights pending...")
    case 'ABSA-CSAT':
        st.write("insights for 2024-10-05 ...")
        md_file_name = 'absa_csat_groups_2024-10-05_insights.md'
        md_path_file = data_output_path / md_file_name
        # Load the markdown file
        with open(str(md_path_file), "r") as markdown_file:
            markdown_content = markdown_file.read()

        # Display the markdown content
        # st.markdown(markdown_content, unsafe_allow_html=True)

        # st.markdown(t_text, unsafe_allow_html=True)
        with st.expander("See Markdown Content"):
            st.markdown(markdown_content)
    case 'Topic Modeling - NMF':
        st.write("insights pending...")
    case 'Topic Modeling - BERTopic':
        st.write("insights pending...")
    case _:
        header_text = 'error, check match structure, unsure what insights to display.'



# ******************* Display Data *************************************************************
# st.subheader('Data')
# # https://docs.streamlit.io/develop/api-reference/data/st.dataframe
# match analysis_type:
#     case 'ABSA-NPS':
#         st.dataframe(df_absa_groups)
#     case 'ABSA-CSAT':
#         st.dataframe(df_absa_groups)
#     case 'Topic Modeling - NMF':
#         cols_to_use = ['probable_topic', 'num_of_docs_per_topic', 'sentiment', 'sentiment_score', 'trigger',
#                        'explanation', 'features', 'term_importance']
#         st.dataframe(df_topic_modeling.loc[:, cols_to_use])
#     case 'Topic Modeling - BERTopic':
#         cols_to_use = ['probable_topic', 'sentiment', 'sentiment_score', 'Count', 'explanation',
#                        'Representative_Docs', 'Representation']
#         # cols_to_use = ['probable_topic']
#         st.dataframe(df_topic_modeling.loc[:, cols_to_use])
#     case _:
#         header_text = 'error, check match structure, unsure what analysis dataframe to display.'


