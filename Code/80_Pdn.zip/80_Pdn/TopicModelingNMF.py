
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.decomposition import NMF
import numpy as np
import pandas as pd
from pathlib import Path
from tqdm import tqdm
from openai import OpenAI
import json
import re
from dotenv import load_dotenv
import os
import sys
import time

common_code_path = Path.cwd().parent / "plp_common_code"
# print(common_code_path)

if str(common_code_path) not in sys.path:
    sys.path.append(str(common_code_path))
from amhere import foundme
foundme()  # this fn will fail if common code path is not found or !exists
del foundme
del common_code_path

from clf_Helper import load_hf_pdt_clf


class TopicModelingNMF:
    def __init__(self, num_topics: int=20, num_top_words: int=10, dlg_date: str='', dlg_id: list[str]=None):
        """
        For POC, this class ONLY loads from database/aspect_topic_db.parquet

        Can either load by a specific date or a list of specific dlg_ids
        if both are passed in, precedence is given to date and dlg_id is ignored

        :param dlg_date:
        :param dlg_id:
        """
        self.n_topics = num_topics
        self.n_top_words = num_top_words
        self._feature_names = None
        self._W = None
        self._H = None

        self._dlg_date = dlg_date if dlg_date is not None and len(dlg_date) > 0 else None
        self._dlg_id = dlg_id if dlg_id is not None and len(dlg_id) > 0 else None

        cwd = Path.cwd()
        db_path = cwd / 'database'
        db_file_name = 'aspect_topic_db.parquet'  # db path
        self._database_path_file = db_path / db_file_name
        self._output_path = cwd / 'data_output'

        save_file_name = 'topic_modeling_nmf_results' + '_' + self._dlg_date
        csv_save_file_name = save_file_name + '.csv'
        parquet_save_file_name = save_file_name + '.parquet'
        self._output_csv_path_file = self._output_path / csv_save_file_name
        self._output_parquet_path_file = self._output_path / parquet_save_file_name

        self._env_path = cwd.parent.parent  # secrets path

        self._df = None
        self._load_customer_utterances()

        self.topics = None  # a DF that holds the final results of the topics found by NMF

    def _load_customer_utterances(self):
        if self._dlg_date is not None:
            # load by date
            tempdf = pd.read_parquet(self._database_path_file)
            fc = tempdf['date'] == self._dlg_date
            self._df = tempdf.loc[fc, :].copy()
            del tempdf
        elif self._dlg_id is not None:
                # load by list of dlg_id
                raise NotImplemented('loading by list of dlg_id is not implemented yet')
        else:
            # load everything
            self._df = pd.read_parquet(self._database_path_file)

    def run(self):
        # Convert to list
        ds_sgd_text = self._df['text'].tolist()

        # vectorise customer utterances
        tfidf_vectorizer = TfidfVectorizer(
            stop_words='english',  # Remove common English stopwords
            max_features=5000,  # maybe if dataset is larger, I may increase to larger number of features
            ngram_range=(1, 2),  # Use uni-grams and bigrams
            max_df=0.95,  # Ignore terms that appear in more than 95% of the documents
            min_df=2  # Ignore terms that appear in less than 2 documents
        )
        X_tfidf = tfidf_vectorizer.fit_transform(ds_sgd_text)
        self._feature_names = tfidf_vectorizer.get_feature_names_out()

        nmf_model = NMF(n_components=self.n_topics, random_state=42)  # components means topics
        self._W = nmf_model.fit_transform(X_tfidf)  # Document-topic matrix aka Features
        self._H = nmf_model.components_  # Topic-term matrix aka Components aka Topics
        # print(self._W.shape, self._H.shape)

        # call create_topics_df
        self._create_topics_df()

        # call LLM to give likely human-readable topic, trigger and explanation
        # currently this is tested only with OpenAI GPT4o
        self._llm_predict_details()

        # get sentiment
        # self._get_sentiment()  # accuracy not good enough, to retrain with better training data
        self._llm_predict_sentiment()  # meantime, use LLM first

        # add sentiment score
        def add_sentiment_score(x):
            match x:
                case 'very negative':
                    return 1
                case 'negative':
                    return 2
                case 'neutral':
                    return 3
                case 'positive':
                    return 4
                case 'very positive':
                    return 5
                case _:
                    raise SystemError('Unknown sentiment polarity.')

        self.topics['sentiment_score'] = self.topics['sentiment'].apply(lambda x: add_sentiment_score(x))

        # save results to data_output folder, these are calculations, not database
        self.topics.to_csv(self._output_csv_path_file, index=False, encoding='utf-8-sig')
        self.topics.to_parquet(self._output_parquet_path_file, index=False)

        # raise NotImplemented('call LLM to create trigger etc')


    def _create_topics_df(self):
        topic_lst = []
        num_of_docs_per_topic = np.sum(self._W > 0, axis=0)  # num of docs per topic
        term_importance = np.sum(self._H, axis=1)  # significance of terms for each topic
        topic_importance = num_of_docs_per_topic + term_importance  # to decide later if shd use weights for the terms

        top_n_words = []

        for topic_idx, topic in enumerate(self._H):
            topic_lst.append(topic_idx)
            top_features = [self._feature_names[i] for i in topic.argsort()[:-self.n_top_words-1:-1]]
            top_words = ", ".join(top_features)
            top_n_words.append(top_words)
        data_0 = {
            "topic_num": topic_lst,
            "topic_importance": topic_importance,
            "num_of_docs_per_topic": num_of_docs_per_topic,
            "term_importance": term_importance,
            "features": top_n_words}
        self.topics = pd.DataFrame(data_0).sort_values(by=['topic_importance'], ascending=False)
        self.topics.reset_index(drop=True, inplace=True)

    def _llm_predict_details(self):
        load_dotenv(dotenv_path=self._env_path / '.env')
        openai_api_key = os.getenv('OPENAI_API_KEY')

        if openai_api_key:
            print(f"OpenAI API Key: Found")
        else:
            print("API Key not found. Please ensure it is in the .env file.")

        client = OpenAI()

        def make_prompt(feature_list: str):
            p1 = """Given a list of words related to the Banking sector, give me the most probable topic,  """
            p2 = """a short concise sentence from the customer perspective on what might have triggered the topic (the trigger), """
            p3 = """and a short explanation. Please reply using in JSON format using the following keys: """
            p4 = """'topic', 'trigger', 'explanation'. Do not reply with anything else. """
            p5 = """Give stronger emphasis to any verbs in the word list. If there are more than one verb in the list, """
            p6 = """give stronger emphasis to earlier verbs.  The word list is: """
            return p1 + p2 + p3 + p4 + p5 + p6 + "\n" + feature_list

        def get_dict_from_openai_completion(c):
            c_content = c.choices[0].message.content
            match = re.search(r'\{.*?\}', c_content, re.DOTALL)
            if match:
                json_str = match.group(0)
                return json.loads(json_str)
            else:
                print("No match found")
                print(c)
                print('*' * 50)

        completion_lst = []

        for i in tqdm(range(self.n_topics)):
            prompt = make_prompt(self.topics.loc[i, 'features'])
            completion = client.chat.completions.create(
                model="gpt-4o",
                messages=[
                    {"role": "user", "content": prompt}
                ]
            )
            completion_lst.append(get_dict_from_openai_completion(completion))
            time.sleep(0.5)  # avoid hitting OpenAI api rate limiter

        topic_lst = [i['topic'] for i in completion_lst]
        trigger_lst = [i['trigger'] for i in completion_lst]
        explain_lst = [i['explanation'] for i in completion_lst]

        self.topics['probable_topic'] = topic_lst
        self.topics['trigger'] = trigger_lst
        self.topics['explanation'] = explain_lst


    def _get_sentiment(self):
        sentiment_clf = load_hf_pdt_clf(
            nlp_task='text-classification',
            hf_model_chkpt="richardchai/plp_sentiment_clr_distilbert")

        def predict_sentiment(x: [str, list]):
            response = sentiment_clf(x)
            sentiment = [r['label'] for r in response]
            if isinstance(sentiment, list) and len(sentiment) < 2:
                return sentiment[0]
            else:
                return str(sentiment)[1:-1]

        self.topics['sentiment'] = self.topics['trigger'].apply(lambda x: predict_sentiment(x))

    def _llm_predict_sentiment(self):
        load_dotenv(dotenv_path=self._env_path / '.env')
        openai_api_key = os.getenv('OPENAI_API_KEY')

        if openai_api_key:
            print(f"OpenAI API Key: Found")
        else:
            print("API Key not found. Please ensure it is in the .env file.")

        client = OpenAI()

        def make_prompt(text: str):
            p1 = """The list of sentiment polarity is: ["very negative', "negative, "neutral", "positive", "very positive"]. """
            p2 = """Given a piece of TEXT, please classify its sentiment polarity. Do not give any explanation. """
            p3 = """Please reply using in JSON format using the following keys: """
            p4 = """'sentiment'. Do not reply with anything else. """
            p5 = f"""\nThe TEXT is: {text}"""
            return p1 + p2 + p3 + p4 + p5

        def get_dict_from_openai_completion(c):
            c_content = c.choices[0].message.content
            match = re.search(r'\{.*?\}', c_content, re.DOTALL)
            if match:
                json_str = match.group(0)
                return json.loads(json_str)
            else:
                print("No match found")
                print(c)
                print('*' * 50)

        completion_lst = []

        for i in tqdm(range(self.topics.shape[0])):
            prompt = make_prompt(self.topics.loc[i, 'trigger'])
            completion = client.chat.completions.create(
                model="gpt-4o",
                messages=[
                    {"role": "user", "content": prompt}
                ]
            )
            completion_lst.append(get_dict_from_openai_completion(completion))
            time.sleep(0.5)  # avoid hitting OpenAI api rate limiter

        # print(completion_lst)

        def recalc_sentiment(s):
            if isinstance(s, list) and len(s) > 1:
                if 'very positive' in s:
                    # very positive is more rare than very negative
                    return 'very positive'
                elif 'very negative' in s:
                    return 'very negative'
                else:
                    # if neither, they cancel each other out
                    return 'neutral'
            elif isinstance(s, list) and len(s) == 0:
                s = 'neutral'
            else:
                return s
        sentiment_lst = [ recalc_sentiment(i['sentiment']) for i in completion_lst]

        # sentiment_lst = [i['sentiment'] for i in completion_lst]
        self.topics['sentiment'] = sentiment_lst

    def print_nmf_topics_listing(self):
        num_documents_per_topic = np.sum(self._W > 0, axis=0)

        for topic_idx, topic in enumerate(self._H):
            print(f"Topic #{topic_idx}:")
            print(f"Num Documents in Topic: {num_documents_per_topic[topic_idx]}")
            print("top features in topic:")
            top_features = [self._feature_names[i] for i in topic.argsort()[:-self.n_top_words- 1:-1]]
            print(", ".join(top_features))
            print()

    def print_me(self):
        print(self._df.shape)
        print(self._df.head(2))


if __name__ == "__main__":
    """
    for this version, there is only dlg_date i.e. both start and end dates equals dlg_date
    """
    nmf = TopicModelingNMF(num_topics=20, num_top_words=10, dlg_date='2024-10-05')
    # nmf = TopicModelingNMF(num_topics=20, num_top_words=10, dlg_date='2024-10-23')
    nmf.run()
    print(nmf.topics)
    pass
