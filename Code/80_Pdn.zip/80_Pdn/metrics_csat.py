# cSAT Metric

import duckdb as ddb
from metrics import Metrics

class MetricsCSAT(Metrics):
    def __init__(self):
        super().__init__()
        print('\n', self._db_aspect_topic.shape)
        self.subset_aspect_topic_by_date_range(start_dtd='2024-10-10')
        self.csat_groups = None
        self.csat_score = None

    def run(self):
        # convert sentiment polarity text labels to floating point scores
        def convert_sentiment_to_score(x):
            x = x.lower()
            match x:
                case 'very negative':
                    return 1.0
                case 'negative':
                    return 2.0
                case 'neutral':
                    return 3.0
                case 'positive':
                    return 4.0
                case 'very positive':
                    return 5.0
                case _:
                    raise SystemError('sentiment polarity is unknown value')
        self._db_at_subset['csat_lbl_score'] = (
            self._db_at_subset['sentiment'].apply(lambda x: convert_sentiment_to_score(x)))

        # create nps groups
        dft = self._db_at_subset
        sql_query = f"""
        select 
        aspect_topic 
        ,avg(csat_lbl_score) as avg_csat_lbl_score 
        ,case
            when avg_csat_lbl_score >= 4.5 then 'very satisfied'
            when avg_csat_lbl_score >= 3.1 then 'satisfied'
            when avg_csat_lbl_score >= 2.9 then 'neutral'
            when avg_csat_lbl_score >= 1.5 then 'unsatisfied'
            else 'very unsatisfied'
        end as csat_group 
        , ANY_VALUE(dlg_id) as rep_dlg_id -- representative dialog id
        , ANY_VALUE(text) as rep_text  -- representative text
        from dft
        group by aspect_topic
        order by avg_csat_lbl_score desc, aspect_topic;
        """
        self.csat_groups = ddb.query(sql_query).to_df()
        del dft

        df_csat_groups = self.csat_groups
        sql_query = f"""
        with satisfied as (
            select count(*) as num_satisfied from df_csat_groups 
            where csat_group = 'satisfied' or csat_group = 'very satisfied' 
        )
        ,responses as (select count(*) as total_responses from df_csat_groups)
        select s.num_satisfied, r.total_responses
        ,(s.num_satisfied/r.total_responses * 100) as csat_score
        from satisfied as s, responses as r;
        """
        self.csat_score = ddb.query(sql_query).to_df()
        del df_csat_groups

        # save groups
        save_file_name = 'absa_csat_groups_' + self._dlg_start_date
        csv_save_file_name = save_file_name + '.csv'
        parquet_save_file_name = save_file_name + '.parquet'
        self._output_csv_path_file = self._output_path / csv_save_file_name
        self._output_parquet_path_file = self._output_path / parquet_save_file_name
        self.csat_groups.to_csv(self._output_csv_path_file, index=False, encoding='utf-8-sig')
        self.csat_groups.to_parquet(self._output_parquet_path_file, index=False)

        # save score
        save_file_name = 'absa_csat_score_' + self._dlg_start_date
        csv_save_file_name = save_file_name + '.csv'
        parquet_save_file_name = save_file_name + '.parquet'
        self._output_csv_path_file = self._output_path / csv_save_file_name
        self._output_parquet_path_file = self._output_path / parquet_save_file_name
        self.csat_score.to_csv(self._output_csv_path_file, index=False, encoding='utf-8-sig')
        self.csat_score.to_parquet(self._output_parquet_path_file, index=False)

        return self.csat_groups, self.csat_score

if __name__ == "__main__":
    metrics_csat = MetricsCSAT()
    # metrics_csat.subset_aspect_topic_by_date_range(start_dtd='2024-10-05', end_dtd='2024-10-05')
    metrics_csat.subset_aspect_topic_by_date_range(start_dtd='2024-10-23', end_dtd='2024-10-23')
    csat_groups, csat_score = metrics_csat.run()
    # print(df[['sentiment', 'sentiment_score']].sample(5))
    print()
    print(csat_groups.head(5))
    print()
    print()
    print(csat_score)