# from datasets import load_dataset
from bertopic import BERTopic
from textblob.en import sentiment
from transformers import AutoModel, AutoTokenizer
from sklearn.feature_extraction.text import CountVectorizer
import torch
import pandas as pd
from tqdm import tqdm
from openai import OpenAI
import json
import re
from pathlib import Path
from dotenv import load_dotenv
import os
import sys
import time

common_code_path = Path.cwd().parent / "plp_common_code"
print(common_code_path)

if str(common_code_path) not in sys.path:
    sys.path.append(str(common_code_path))
from amhere import foundme
foundme()  # this fn will fail if common code path is not found or !exists
del foundme
del common_code_path

from clf_Helper import load_hf_pdt_clf


class TopicModelingBERTopic:
    def __init__(self, top_n_topics: int=20, dlg_date: str='', dlg_id: list[str]=None):
        """
        For POC, this class ONLY loads from database/aspect_topic_db.parquet

        Can either load by a specific date or a list of specific dlg_ids
        if both are passed in, precedence is given to date and dlg_id is ignored

        top_n_topics is to limit the number of topics exported or which use LLM to do stuff.
        BERTopic itself does not need this parameter, it automatically determines the number of topics

        :param dlg_date:
        :param dlg_id:
        """

        # although BERTopic does not require us to specify num of topics upfront, I still want
        # to cap the number of topics to the top_n to reduce the number of calls to LLM
        self.top_n = top_n_topics

        self._dlg_date = dlg_date if dlg_date is not None and len(dlg_date) > 0 else None
        self._dlg_id = dlg_id if dlg_id is not None and len(dlg_id) > 0 else None

        cwd = Path.cwd()
        db_path = cwd / 'database'
        db_file_name = 'aspect_topic_db.parquet'  # db path
        self._database_path_file = db_path / db_file_name
        self._output_path = cwd / 'data_output'

        save_file_name = 'topic_modeling_bertopic_results' + '_' + self._dlg_date
        csv_save_file_name = save_file_name + '.csv'
        parquet_save_file_name = save_file_name + '.parquet'
        self._output_csv_path_file = self._output_path / csv_save_file_name
        self._output_parquet_path_file = self._output_path / parquet_save_file_name

        self._env_path = cwd.parent.parent  # secrets path

        self._df = None
        self._load_customer_utterances()

        self._topic_model = None
        self.topics = None  # a DF that holds the final results of the topics found by NMF
        self.topics_top_n = None

    def _load_customer_utterances(self):
        if self._dlg_date is not None:
            # load by date
            tempdf = pd.read_parquet(self._database_path_file)
            fc = tempdf['date'] == self._dlg_date
            self._df = tempdf.loc[fc, :].copy()
            del tempdf
        elif self._dlg_id is not None:
                # load by list of dlg_id
                raise NotImplemented('loading by list of dlg_id is not implemented yet')
        else:
            # load everything
            self._df = pd.read_parquet(self._database_path_file)

    def run(self):
        # BERTopic Modelling code
        model_name = "sentence-transformers/all-MiniLM-L6-v2"
        tokenizer = AutoTokenizer.from_pretrained(model_name)
        model = AutoModel.from_pretrained(model_name)

        # Convert to list
        ds_sgd_text = self._df['text'].tolist()

        # create embeddings
        def embed_texts(texts, tokenizer, model):
            # Tokenize and encode the texts
            inputs = tokenizer(texts, padding=True, truncation=True, return_tensors="pt", max_length=512)

            # Get the model embeddings
            with torch.no_grad():
                model_output = model(**inputs)

            # Use the CLS token representation as the sentence embedding
            embeddings = model_output.last_hidden_state[:, 0, :].numpy()
            return embeddings

        # Generate embeddings for the dialogues
        print('\nBegin embedding customer utterances, this could take a while ...')
        dlg_embeddings = embed_texts(ds_sgd_text, tokenizer, model)
        print('End of embedding customer utterances.\n')

        # fit BERTopic using dlg_embeddings
        # BERTopic needs a CountVectorizer for creating topics
        print('Begin creating vectorizer model, this could take a while ...')
        vectorizer_model = CountVectorizer(stop_words="english", ngram_range=(1, 2))
        print('End of creating vectorizer model.\n')

        # Initialize BERTopic model
        self._topic_model = BERTopic(vectorizer_model=vectorizer_model)

        # Fit the model to the dialogues and embeddings
        # topics, probabilities = topic_model.fit_transform(ds_sgd_text, dlg_embeddings)
        print('Begin fitting the topic model, this could take a while ...')
        _, _ = self._topic_model.fit_transform(ds_sgd_text, dlg_embeddings)
        print('end of fitting topic model.\n')

        self.topics = self._topic_model.get_topic_info()  # pandas df
        self.topics.reset_index(drop=True, inplace=True)
        # topic at row 0 is for outliers, we start from 1:
        self.topics_top_n = self.topics.loc[1: self.top_n, :].copy()
        self.topics_top_n.reset_index(drop=True, inplace=True)

        # Examine the top words for each topic in the Top N topics with p-values
        # for topic_idx in self.topics['Topic'][:5]:
        #     if topic_idx != -1:  # Ignore the -1 label which is for outliers
        #         print(f"\nTopic {topic_idx}:")
        #         print(self._topic_model.get_topic(topic_idx))

        # call LLM to give likely human-readable topic, trigger and explanation
        # currently this is tested only with OpenAI GPT4o
        self._llm_predict_details()

        # get sentiment
        # self._get_sentiment()  # accuracy not good enough, need to retrain with better training data
        self._llm_predict_sentiment()  # meantime, use LLM first

        # add sentiment score
        def add_sentiment_score(x):
            match x:
                case 'very negative':
                    return 1
                case 'negative':
                    return 2
                case 'neutral':
                    return 3
                case 'positive':
                    return 4
                case 'very positive':
                    return 5
                case _:
                    raise SystemError('Unknown sentiment polarity.')

        # print(self.topics.head())
        # input('wait ah')
        self.topics_top_n['sentiment_score'] = self.topics_top_n['sentiment'].apply(lambda x: add_sentiment_score(x))

        # save results to data_output folder, these are calculations, not database
        print(self._output_csv_path_file)
        print(self._output_parquet_path_file)
        self.topics_top_n.to_csv(self._output_csv_path_file, index=False, encoding='utf-8-sig')
        self.topics_top_n.to_parquet(self._output_parquet_path_file, index=False)


    def _llm_predict_details(self):
        load_dotenv(dotenv_path=self._env_path / '.env')
        openai_api_key = os.getenv('OPENAI_API_KEY')

        if openai_api_key:
            print(f"OpenAI API Key: Found")
        else:
            print("API Key not found. Please ensure it is in the .env file.")

        client = OpenAI()

        def make_prompt(rep_words: list, rep_docs: list):
            p1 = f"""The representative words are: {rep_words}. """
            p2 = f"""The representative docs are: {rep_docs}. """
            p3 = """From the list of Representative words and list of Representative Docs, create a topic and a short explanation. """
            p4 = """Please reply using in JSON format using the following keys: 'topic', explanation'. Do not reply with anything else.  """
            p5 = """ """
            p6 = """ """
            return p1 + p2 + p3 + p4 + p5 + p6

        def get_dict_from_openai_completion(c):
            c_content = c.choices[0].message.content
            match = re.search(r'\{.*?\}', c_content, re.DOTALL)
            if match:
                json_str = match.group(0)
                return json.loads(json_str)
            else:
                print("No match found")
                print(c)
                print('*' * 50)

        completion_lst = []

        for i in tqdm(range(self.topics_top_n.shape[0])):
            prompt = make_prompt(
                self.topics_top_n.loc[i, 'Representation'],
                self.topics_top_n.loc[i, 'Representative_Docs'])

            completion = client.chat.completions.create(
                model="gpt-4o",
                messages=[
                    {"role": "user", "content": prompt}
                ]
            )
            completion_lst.append(get_dict_from_openai_completion(completion))
            time.sleep(0.5)  # avoid hitting OpenAI api rate limiter

        topic_lst = [i['topic'] for i in completion_lst]
        explain_lst = [i['explanation'] for i in completion_lst]

        self.topics_top_n['probable_topic'] = topic_lst
        self.topics_top_n['explanation'] = explain_lst


    def _get_sentiment(self):
        sentiment_clf = load_hf_pdt_clf(
            nlp_task='text-classification',
            hf_model_chkpt="richardchai/plp_sentiment_clr_distilbert")

        def predict_sentiment(x: [str, list]):
            if isinstance(x, list):
                x = str(x)[1:-1]

            response = sentiment_clf(x)
            sentiment = [r['label'] for r in response]
            if isinstance(sentiment, list) and len(sentiment) < 2:
                return sentiment[0]
            else:
                return str(sentiment)[1:-1]

        self.topics_top_n['sentiment'] = (
            self.topics_top_n['Representative_Docs'].apply(lambda x: predict_sentiment(x[0])))

    def _llm_predict_sentiment(self):
        load_dotenv(dotenv_path=self._env_path / '.env')
        openai_api_key = os.getenv('OPENAI_API_KEY')

        if openai_api_key:
            print(f"OpenAI API Key: Found")
        else:
            print("API Key not found. Please ensure it is in the .env file.")

        client = OpenAI()

        def make_prompt(text: str):
            p1 = """The list of sentiment polarity is: ["very negative', "negative, "neutral", "positive", "very positive"]. """
            p2 = """Given a piece of TEXT, please classify its sentiment polarity. Do not give any explanation. """
            p3 = """Please reply using in JSON format using the following keys: """
            p4 = """'sentiment'. Do not reply with anything else. """
            p5 = f"""\nThe TEXT is: \n{text}"""
            return p1 + p2 + p3 + p4 + p5

        def get_dict_from_openai_completion(c):
            c_content = c.choices[0].message.content
            match = re.search(r'\{.*?\}', c_content, re.DOTALL)
            if match:
                json_str = match.group(0)
                return json.loads(json_str)
            else:
                print("No match found")
                print(c)
                print('*' * 50)

        completion_lst = []

        for i in tqdm(range(self.topics_top_n.shape[0])):
            prompt = make_prompt(self.topics_top_n.loc[i, 'Representative_Docs'])
            completion = client.chat.completions.create(
                model="gpt-4o",
                messages=[
                    {"role": "user", "content": prompt}
                ]
            )
            completion_lst.append(get_dict_from_openai_completion(completion))
            time.sleep(0.5)  # avoid hitting OpenAI api rate limiter

        # print(completion_lst)

        # LLM is supposed to return just sentiment value, but sometimes, it gives more then one answer
        # e.g. instead of "neutral", it returns [negative, positive, neutral]
        # but we only want 1 answer
        # if I have time, I will change the below to the more accurate method I developed.

        def recalc_sentiment(s):
            if isinstance(s, list) and len(s) > 1:
                if 'very positive' in s:
                    # very positive is more rare than very negative
                    return 'very positive'
                elif 'very negative' in s:
                    return 'very negative'
                else:
                    # if neither, they cancel each other out
                    return 'neutral'
            elif isinstance(s, list) and len(s) == 0:
                s = 'neutral'
            else:
                return s
        sentiment_lst = [ recalc_sentiment(i['sentiment']) for i in completion_lst]

        # print('\n', sentiment_lst, '\n')
        # print()
        # print(self.topics_top_n.columns)
        # input('wait ah')

        self.topics_top_n['sentiment'] = sentiment_lst
        # print()
        # print(self.topics_top_n.loc[:, 'sentiment'])


    def print_me(self):
        print('*' * 100)
        print(self.topics.shape)
        print(type(self.topics))
        print(self.topics.head(2))
        print('*' * 100)


if __name__ == "__main__":
    """
        for this version, there is only dlg_date i.e. both start and end dates equals dlg_date
    """
    # tmBertTopic = TopicModelingBERTopic(top_n_topics=20, dlg_date='2024-10-05')
    tmBertTopic = TopicModelingBERTopic(top_n_topics=20, dlg_date='2024-10-23')
    tmBertTopic.run()
    # tmBertTopic.print_me()


    # nmf.run()
    # print(nmf.topics)
    pass
