# NPS Metric

import duckdb as ddb
from metrics import Metrics

class MetricsNPS(Metrics):
    def __init__(self):
        super().__init__()
        print('\n', self._db_aspect_topic.shape)
        self.subset_aspect_topic_by_date_range(start_dtd='2024-10-10')
        self.nps_groups = None
        self.nps_score = None

    def run(self):
        # convert sentiment polarity text labels to floating point scores
        def convert_sentiment_to_score(x):
            x = x.lower()
            match x:
                case 'very negative':
                    return 0.0
                case 'negative':
                    return 2.5
                case 'neutral':
                    return 5.0
                case 'positive':
                    return 7.5
                case 'very positive':
                    return 10.0
                case _:
                    raise SystemError('sentiment polarity is unknown value')
        self._db_at_subset['sentiment_score'] = (
            self._db_at_subset['sentiment'].apply(lambda x: convert_sentiment_to_score(x)))

        # create nps groups
        dft = self._db_at_subset
        sql_query = f"""
        select 
        aspect_topic 
        ,avg(sentiment_score) as avg_sentiment_score 
        ,case
            when avg_sentiment_score >= 9 then 'promoters'
            when avg_sentiment_score >= 7 then 'passives'
            else 'detractors'
        end as nps_group 
        , ANY_VALUE(dlg_id) as rep_dlg_id -- representative dialog id
        , ANY_VALUE(text) as rep_text  -- representative text
        from dft
        group by aspect_topic
        order by avg_sentiment_score desc, aspect_topic;
        """
        self.nps_groups = ddb.query(sql_query).to_df()
        del dft

        df_nps_groups = self.nps_groups
        sql_query = """
        with 
        respondents as (select count(*) as total_respondents from df_nps_groups)
        ,promoters as (select count(*) as num_promoters from df_nps_groups where nps_group = 'promoters')
        , detractors as (select count(*) as num_detractors from df_nps_groups where nps_group = 'detractors')
        select
        r.total_respondents
        ,p.num_promoters
        ,(p.num_promoters / r.total_respondents * 100) as pct_promoters
        ,d.num_detractors
        ,(d.num_detractors / r.total_respondents * 100) as pct_detractors
        ,(pct_promoters - pct_detractors) as nps -- can range from -100 to +100
        from respondents as r, promoters as p, detractors as d
        ;
        """
        self.nps_score = ddb.query(sql_query).to_df()
        del df_nps_groups

        # save groups
        save_file_name = 'absa_nps_groups_' + self._dlg_start_date
        csv_save_file_name = save_file_name + '.csv'
        parquet_save_file_name = save_file_name + '.parquet'
        self._output_csv_path_file = self._output_path / csv_save_file_name
        self._output_parquet_path_file = self._output_path / parquet_save_file_name
        self.nps_groups.to_csv(self._output_csv_path_file, index=False, encoding='utf-8-sig')
        self.nps_groups.to_parquet(self._output_parquet_path_file, index=False)

        # save score
        save_file_name = 'absa_nps_score_' + self._dlg_start_date
        csv_save_file_name = save_file_name + '.csv'
        parquet_save_file_name = save_file_name + '.parquet'
        self._output_csv_path_file = self._output_path / csv_save_file_name
        self._output_parquet_path_file = self._output_path / parquet_save_file_name
        self.nps_score.to_csv(self._output_csv_path_file, index=False, encoding='utf-8-sig')
        self.nps_score.to_parquet(self._output_parquet_path_file, index=False)

        return self.nps_groups, self.nps_score

if __name__ == "__main__":
    metrics_nps = MetricsNPS()
    # metrics_nps.subset_aspect_topic_by_date_range(start_dtd='2024-10-05', end_dtd='2024-10-05')
    metrics_nps.subset_aspect_topic_by_date_range(start_dtd='2024-10-23', end_dtd='2024-10-23')
    nps_groups, nps_score = metrics_nps.run()
    # print(df[['sentiment', 'sentiment_score']].sample(5))
    print()
    print(nps_groups.head(2))
    print()
    print(nps_score)