
from pathlib import Path
import pandas as pd

class PrepData:
    """
    imports multi-turn dialog
    """
    def __init__(self, input_path_file: Path):
        self.input_path_file = input_path_file
        self.df_input = pd.read_parquet(self.input_path_file)

        print(self.df_input.shape)
        print(self.df_input.columns)






def prepare_multiturn_dialog():

    """
    this fn receives the parquet file containing multi-turn dialog with the format of:
    
    tbc
    customer: ""
    agent: ""
    
    
    then extracts customer utterance only
    does basic cleaning
    and returns it back to the caller.
    
    *** Double check what the jupyter notebook did
    
    *** Should I also accept text file?
    
    """
    pass