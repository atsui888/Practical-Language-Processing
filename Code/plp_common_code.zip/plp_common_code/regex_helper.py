# regex_helper.py

import re

def filter_interest_items(source_list, items_of_interest):
    # Combine items of interest into a single regex pattern using word boundaries
    pattern = r'\b(?:' + '|'.join(re.escape(item) for item in items_of_interest) + r')\b'
    
    # Filter the source list based on whether the element contains any item of interest
    filtered_list = [item for item in source_list if re.search(pattern, item, re.IGNORECASE)]    
    return filtered_list


def lowercase_list_elements(str_list):
    """
    Lowercases each string in the input list.

    Args:
        str_list (list): A list of strings.

    Returns:
        list: A list of lowercased strings.
        
    notes:
        the re.sub function removes any non-alphanumeric characters (except spaces) before 
        lowercasing the string. 
    """
    return [re.sub(r"[^a-zA-Z0-9\s]", "", string).lower() for string in str_list]


def remove_punctuation_elements(lst):
    # Define the regex pattern for elements that contain only punctuation
    # pattern = r'^[,;.!?]+$'
    pattern = r'^[,;.!?\'\"]+$'
    
    # Use list comprehension to filter out elements that match the pattern
    filtered_list = [item for item in lst if not re.fullmatch(pattern, item)]
    return filtered_list


def remove_short_elements(lst, min_word_threshold=5):
    # Filter elements that have 5 or more words
    filtered_list = [item for item in lst if len(re.findall(r'\b\w+\b', item)) >= min_word_threshold]
    return filtered_list
    

def split_paragraph(paragraph):
    # Define the regex pattern to split based on the specified delimiters
    pattern = r'(?<=[,;.!?])\s*|\s*(?=[,;.!?])'
    
    # Use re.split to split the paragraph into components
    components = [sentence.strip() for sentence in re.split(pattern, paragraph) if sentence.strip()]    
    return components