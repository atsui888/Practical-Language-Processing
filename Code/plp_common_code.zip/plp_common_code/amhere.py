
def foundme():
    return "common code folder found."