import numpy as np
from typing import Union
from datasets import ClassLabel, DatasetDict, Dataset


def hf_dataset_dict_get_lbl_col_names(dsd: DatasetDict):
    class_label_col_names = {}    
    for k in dsd.keys():  # usually returns 'train' and/or 'test' 
        temp_list = []
        for fk in dsd[k].features.keys():                        
            if isinstance(dsd[k].features[fk], ClassLabel):
                temp_list.append(fk)
                # print(f"{str(k) + ' set / feature: ' + str(fk) + ' is type ClassLabel:':<40}")
                # print(ds[k].features[fk].names)
                # print()
        class_label_col_names[k] = temp_list
    
    return class_label_col_names


def hf_dataset_dict_describe(dsd: DatasetDict) -> None:
    # https://huggingface.co/docs/datasets/v3.0.1/en/package_reference/main_classes#datasets.DatasetDict
    print(f"{'type':<20}: {type(dsd)}")
    print(f"{'\nshape':<20}: {dsd.shape}")  # .num_rows, num_columns
    print(f"{'\nkeys':<20}: {dsd.keys()}")
    print(f"\n{'column_names':<20}: {dsd.column_names}")
    print("\nLabels\n========")
    labels_d = hf_dataset_dict_get_lbl_col_names(dsd)
    for data_split, col_names in labels_d.items():
        for col in col_names:
            print(f"{str(data_split) + ' set / "' + str(col) + '" is type ClassLabel -->':<40}")
            print(dsd[data_split].features[col].names)
            print()
        
def hf_dataset_describe(hfds: Dataset) -> None:
    # https://huggingface.co/docs/datasets/v3.0.1/en/package_reference/main_classes#datasets.Dataset
    # useful methods: add_column, add_item, remove_columns, rename_column, rename_columns, select_columns
    # cast (can be used to change labels from ['bad', 'good'] to [0, 1]
    # cast_column 
    """
    In the Hugging Face Datasets documentation, the difference between cast and cast_column is as follows:
        cast: This method is used to change the data type of the entire dataset. It allows you to specify a new data type 
            for all columns in the dataset, which can be useful when you want to ensure that all data conforms to a specific type.
        cast_column: This method is more granular and is used to change the data type of a specific column within the dataset. 
            This allows for targeted adjustments without affecting other columns.
    In summary, use cast for changing types across the whole dataset and cast_column for modifying individual columns.
    """
    # class_encode_column: Casts the given column as ClassLabel and updates the table.
    # set_format e.g. ds.set_format(type='numpy', columns=['text', 'label']), followed by ds.format (to check the format)
    # set_transform, reset_format, map, filter, select, sort, shuffle
    # skip, take(n), train_test_split, to_tf/csv/pandas/dict/json/parquet/sql/iterable_dataset, push_to_hub, load/save_to_disk, 
    # add/load/save_faiss_index, other types of index, search 
    # from_csv/json/parquet/text/sql etc
    # align_labels_with_mapping
    """
    https://huggingface.co/docs/datasets/v3.0.1/en/package_reference/main_classes#datasets.Dataset.align_labels_with_mapping
    Align the dataset’s label ID and label name mapping to match an input label2id mapping. T
    his is useful when you want to ensure that a model’s predicted labels are aligned with the dataset. 
    The alignment in done using the lowercase label names.

    """
   
    print(f"{'type':<20}: {type(hfds)}")
    print(f"{'shape':<20}: {hfds.shape}")  # .num_rows, num_columns
    print(f"{'features.keys()':<20}: {sorted(hfds.features.keys())}")
    print(f"{'Num of Rows':<20}: {hfds.num_rows}")
    print(f"{'Num of Columns':<20}: {hfds.num_columns}")
    print(f"{'column_names':<20}: {hfds.column_names}")
    print("\nClassLabel")
    print("------")
    for fk in hfds.features.keys():         
        if isinstance(hfds.features[fk], ClassLabel):
            print(f"{fk:<20}")
            print(f"len: {len(hfds.unique(fk))}")
            for i in (sorted(hfds.unique(fk))):
                print(i, end=", ")
            print('\n')
    print("\n.info")
    print("------")
    print(hfds.info)        
    
    
def hf_dataset_display_random_rows(n_rows: int, hfds: Dataset, lbl_col='label', text_col='text') -> None: 
    indexes = [i for i in range(len(hfds))]
    indexes_to_display = [int(np.random.choice(indexes)) for i in range(n_rows)]
    # print(len(indexes))
    # print(indexes_to_display)

    for i, row_idx in enumerate(indexes_to_display):        
        print(f"{'row ' + str(i+1) + ':':<20}")
        print(f"Text: {hfds[row_idx][text_col]}")
        if lbl_col is not None and len(text_col) > 0:
            class_idx = hfds[row_idx][lbl_col]
            class_lbl = hfds.features[lbl_col].names[class_idx]
            print(f"Label idx: {class_idx} --> {class_lbl}\n")
        

def hf_dataset_display_row(row_num: int, hfds: Dataset, lbl_col='label', text_col='text') -> None: 
    class_idx = hfds[row_num][lbl_col]
    class_lbl = hfds.features[lbl_col].names[class_idx]
    print(f"{'row ' + str(row_num) + ':':<20}")
    print(f"Text: {hfds[row_num][text_col]}")
    print(f"Label idx: {class_idx} --> {class_lbl}\n")
        
def hf_dataset_get_labels(hfds: Dataset, lbl_col='label') -> dict:
    num_classes = hfds.features[lbl_col].num_classes
    return {i:hfds.features[lbl_col].names[i] for i in range(num_classes)}

def hf_dataset_display_labels(hfds: Dataset, lbl_col='label') -> dict:
    num_classes = hfds.features[lbl_col].num_classes
    lbl_d = {i:hfds.features[lbl_col].names[i] for i in range(num_classes)}
    for k, v in lbl_d.items():
        print(f"{k:<2} --> {v}")
