import torch
from transformers import pipeline

def load_hf_pdt_clf(nlp_task: str, hf_model_chkpt: str):
    device = 0 if torch.cuda.is_available() else -1
    return pipeline(nlp_task, model=hf_model_chkpt, device=device)
    